<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard6_C extends CI_Controller {

	public function index()
	{
		$this->load->view('Dashboard6_V');
		
	}
}